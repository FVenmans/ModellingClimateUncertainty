%Collocation method
clear; close all;
addpath '/MATLAB Drive/compecon/CEtools'
%cepath='C:\Users\frank\Google Drive\Google Research Rest\MATLAB\compecon\'; path([cepath 'CEtools;' cepath 'CEdemos'],path);
%home=>add-Ons => install MinGW-w64  => mexall (for speed)

%PARAMETERS
% preferences 
    rho=0.011-0.005;  %utility discount rate reduced by population growth
    eta=1.35;           %elasticity of marginal utility wrt consumption
    RRA=4;              %Relative risk aversion for Esptein-Zin
    %discount=exp(-delta);
%economic model 
    g=0.02;             %exogenous growth rate
    sigmaS=0.01;        %standard deviation of Brownian motion on S
    A0=5.115;           %total factor productivity from DICE
    L0=7.403;           %popuation from DICE
    alpha=0.3;          %elasticity of capital in Cobb-Douglas from DICE
    K0=223;             %initial capital from DICE
    delta=0.1;          %depreciation rate per year
%Abatement costs
    phi=0.00126;        %MAC intercept
    varphi=0.00003;     %MAC slope
%Climate and damages
    zeta=0.0006;        %TCRE
    gammaT=0.01;        %damage as proportion of GDP is exp(0.5*gammaT*T²)
    gamma=zeta^2*gammaT; % gamma includes the TCRE
    S0=2000;            %initial cumulative emissions

%Organise model parameters in a structure
    [e,w]=qnwnorm(5,0,sigmaS^2); %to make five-node Gaussian quadrature (qnwlogn for lognormal distribution)
    model.func='func_2states'; %user-defined function
    model.discount=exp(-(rho+(eta-1)*g)); 
    model.e=e;          %shocks
    model.w=w;          %likelihood of shocks
    model.params={A0,L0,g,alpha,phi,varphi,gamma,delta,eta,RRA,model.discount};

%compute approximate steady state from theory
    Sstar= (rho+(eta-1)*g)*phi/gamma; % c_/b_ in DietzVenmans2019
    kstar=(A0*exp(-gamma/2*Sstar^2)*alpha/((rho+delta+eta*g(1))))^(1/(1-alpha)) ; %http://www.econ2.jhu.edu/people/ccarroll/Public/LectureNotes/Growth/RamseyCassKoopmans.pdf A in their paper is A^(1/(1-alpha) in my notation

%define chebyshev grid for Value function
    smin=[S0 K0/L0];
    smax=[Sstar kstar];
    n=[6 6];
    fspace=fundefn('cheb',n,smin,smax);
    scoord=funnode(fspace);
    snodes=gridmake(scoord); 

% CHECK MODEL DERIVATIVES AT THE STEADY STATE
    estar=0;%steady state without shocks
    sstar=[Sstar kstar];%state variables at steady state
    xstar=[0 delta*kstar]; %decision varialbes at steady state
    pstar=[0.0004 0.004]; %shadow price
    dpcheck(model,sstar,xstar,estar);

% COMPUTE LINEARQUADRATIC APPROXIMATION
[vlq,xlq,plq,ss,xx,pp]=lqapprox(model,snodes,sstar,xstar,pstar); %the book has estar as last element, this is wrong
  
% SOLVE BELLMAN EQUATION
optset('dpsolve','showiters',1);% show iterations
optset('dpsolve','algorithm','funcit'); %standard is 'newton', 'funcit' is often more stable
optset('dpsolve','tolfuncit',1e-4); % switch from funcit to newton when error is smaller than 1e-4
[c,s,v,x,resid]=dpsolve(model,fspace,snodes,vlq,xlq); 
[cEZ,sEZ,vEZ,xEZ,residEZ]=dpsolveEZ(model,fspace,snodes,vlq,xlq); 

%MONTE CARLO POSTESTIMATION
nyrs=80;%simulation horizon
nrep=500;%number of Monte Carlo simulations
sinit=repmat([S0 K0/L0],nrep,1); 
[spath,xpath]=dpsimul(model,sinit,nyrs,s,x);%MonteCarlo simulation
s1path =mean(squeeze(spath(:,1,:)));%calculate mean of path of S
s2path =mean(squeeze(spath(:,2,:)));
x1path =mean(squeeze(xpath(:,1,:)));
x2path =mean(squeeze(xpath(:,2,:)));

%PLOT MEAN SCENARIOS
figure() %start a new figure. 
    subplot(2,2,1)
        plot(2020:2100,x1path); 
        title('Emissions')
        xlabel('Year');
        ylabel('Emissions (GtCO2eq)');axis([2020 2100 0 inf]);
    subplot(2,2,2);
        plot(2020:2100,x2path);
        title('Investment ');
        xlabel('Year'); 
        ylabel('Investment per unit of effective labour ($000)');
        axis([2020 2100 -inf inf])
    subplot(2,2,3);
        plot(2020:2100,s1path*zeta);
        title('Temperature');
        xlabel('Year'); ylabel('Temperature(°C)');axis([2020 2100 -inf inf]);
    subplot(2,2,4);
        plot(2020:2100,s2path);
        title('Capital');
        xlabel('Year'); ylabel('Capital per unit of effective labour ($000)'); axis([2020 2100 -inf inf]); 
    hold off
    orient 'landscape'
    print('2statesmodel', '-dpdf','-bestfit')