% dpsolveEZFV  Solves discrete time  Bellman equation for Epstein-Zinn preferences
% same as DPSOLVE but adds 
% 1. maxn, the max degree polynomial for complete chebyshev nodes
% 2. option tolfuncit, switch from funcit to newton when error is smaller than tolfuncit
% 3. option howardit, in the funcit loop, after every value function iteration, the Bellman equation (v) is iterated several times without updating the policy function (the controls x)
% 4. Epstein-Zin preferences: each individual outcome to the power (1-RRA)/(1-eta) while expected value of Vt+1 is raised to the power (1-eta)/(1-RRA). model.params and user-written function needs to have as 3 last arguments: eta,RRA,discountrate.  

function [c,scoord,v,x,resid] = dpsolveEZFV(model,fspace,s,v,x,maxn)

% SET PARAMETER & SHOCK DISTRIBUTION DEFAULTS
  tol       = optget('dpsolve','tol',sqrt(eps));
  tolfuncit = optget('dpsolve','tolfuncit',1e-4);   %sets error tolerance in funcit after which it switches to newton. Set to 1e-8 to avoid switching to newton
  howardit  = optget('dpsolve','howardit',1);       %allows to update the policy function after several value function iterations
  maxit     = optget('dpsolve','maxit',500);
  nres      = optget('dpsolve','nres',10);
  showiters = optget('dpsolve','showiters',1);
  algorithm = optget('dpsolve','algorithm','newton');

  if ~isfield(model,'e'); model.e=0; e=0;
    else, e=model.e; end;
  if ~isfield(model,'w'); model.w=1; delw=model.discount;
    else, delw=model.discount*model.w; end;
  if isfield(model,'horizon') & model.horizon<inf, algorithm='finite'; end
  if isfield(model,'actions'), x=model.actions; end
  if isfield(model,'explicit'), explicit=model.explicit; else, explicit=0; end
  func=model.func;
  params=model.params;
  if nargin<3, s=gridmake(funnode(fspace)); end
  if nargin<4 | isempty(v), v = zeros(size(s,1),1); end
  
% DETERMINE NUMBER OF DIMENSIONS & COORDINATES
  n  = fspace.n;                % number of collocation coordinates by state dimension 
  ns = prod(n);                 % number of collocation states
  ds = length(n);               % dimension of state space
  dx = size(x,2);               % dimension of action space
  
% COMPUTE COLLOCATION NODES AND INTERPOLATION MATRIX
  [PhiS,~,N] = funbasxFV(fspace,s,[],'completeChebyshev',maxn);          % collocation matrix
  c   = funfitxyFV(fspace,PhiS,v,N);     % initial basis coefficients
  [F,G,X] = GetFG(s,fspace,model);   % basis functions for discrete states

% SOLVE BELLMAN EQUATION
  tic
  switch algorithm
    case 'funcit'                              % FUNCTION ITERATION
    for it=1:maxit                             % perform iterations
      cold = c;                                % store old basis coefficients
      if explicit
        [v,x] = vmax(s,[],c,fspace,model,F,G,X);  % update value function and policy
      else
            %HOWARD LOOP
            for h=1:howardit 
              if h< howardit 
                  [v] = valfunc(c,fspace,s,x,e,delw,func,params);   % update value function only
                  c     = funfitxyFV(fspace,PhiS,v,N);              % update basis coefficient
              else
                  [v,x] = vmax(s,x,c,fspace,model,F,G,X,maxn);        % update value function and policy
              end
              %else; fprintf( 'problemloop')
            end %END OF HOWARD LOOP
      
%         end
        c   = funfitxyFV(fspace,PhiS,v,N);         % update basis coefficient
        %c=c-0.5*(c-cold) ;  %Suggestion by Traeger, for slower but more stable results. (he suggested 50% , can also be 20%)
          if any(isnan(c))
            error('NaNs encountered')
          end
      end
      change = norm(c-cold,inf);               % compute change
      if change<1e-3 howardit=1;end
      if showiters 
        fprintf ('%4i %10.1e\n',it,change)     % print progress
      end
      %MY CODE: switch to newton when tolfuncit is reached.  
      if change<tolfuncit; algorithm='newton';break;  
      elseif change<tol, break, end;           % convergence check  
    end
  case 'newton'                                % NEWTON METHOD
    %Phi=funbconv(PhiS,zeros(1,ds),'expanded');% not needed, because PhiS is already 'expanded'
    Phi=PhiS.vals{1};
    for it=1:maxit                             % perform iterations
      cold = c;                                % store old basis coefficients
      if explicit
        [v,x,vderc] = vmax(s,[],c,fspace,model,F,G,X,maxn);  % update value function and policy
      else
        [v,x,vderc] = vmax(s,x,c,fspace,model,F,G,X,maxn);  % update value function and policy
      end
      dc=zeros(prod(n),1);
      index=(1:prod(n));
      index=index(logical(N));
      dc(index)=[Phi-vderc]\[Phi*c(N)-v];
      c = cold - dc;        % update basis coefficient
      if any(isnan(c))
        error('NaNs encountered')
      end
      change = norm(c-cold,inf);               % compute change
      if showiters 
        fprintf ('%4i %10.1e\n',it,change)     % print progress
      end

      if change<tol, break, end;               % convergence check  
    end
  case 'finite'                                % BACKWARD RECURSION   
    T  = model.horizon;                        % number of decision periods
    xx = zeros(ns,dx,T);                       % declare action matrix
    vv = [zeros(ns,T) v];                      % declare value matrix
    cc = [zeros(ns,T) c];                      % declare coefficient matrix
    for t=T:-1:1                               % perform recursions
      if explicit
        [v,x] = vmax(s,[],c,fspace,model,F,G,X,maxn);  % update value function and policy
      else
        [v,x] = vmax(s,x,c,fspace,model,F,G,X,maxn);  % update value function and policy
      end
      c     = funfitxyFV(fspace,PhiS,v,N);         % update basis coefficient
      if any(isnan(c))
        error('NaNs encountered')
      end
      xx(:,:,t) = x;                           % store actions
      vv(:,t) = v;                             % store values
      cc(:,t) = c;                             % store coefficients
      if showiters 
        fprintf ('Solving for time %1i\n',t)      % print progress
      end
    end 
    c=cc; v=vv; x=xx; scoord=s;
    return
  end
  if showiters, fprintf('Elapsed Time = %7.2f Seconds\n',toc); end
  
% CHECK STATE TRANSITION SATISFY BOUNDS
  snmin=inf; snmax=-inf;
  for k=1:length(delw);
    kk = k*ones(ns,1);
    g = feval(func,'g',s,x,e(kk,:),params{:});
    snmin = min(snmin,min(g));
    snmax = max(snmax,max(g)); 
  end
  if any(snmin<fspace.a-eps), disp('Warning: extrapolating beyond smin');snmin, end
  if any(snmax>fspace.b+eps), disp('Warning: extrapolating beyond smax');snmax, end
  
  
  % COMPUTE RESIDUAL
  scoord = funnode(fspace);            % state collocaton coordinates
  if ~strcmp(algorithm,'finite') & nargout>4
    ind = ones(1,ds);
    if isfield(model,'discretestates')
      ind(model.discretestates) = 0;
    end
    if ds==1,
      if ind
        n = nres*n;
        scoord = linspace(fspace.a,fspace.b,n)';
      end
    else 
      for i=1:ds, 
        if ind(i)
          n(i) = nres*n(i);
          scoord{i} = linspace(fspace.a(i),fspace.b(i),n(i))';
        end
      end
    end
    s = gridmake(scoord);
    if isempty(F)
      if explicit
        x=[];
      else
        x = funeval(funfitxyFV(fspace,PhiS,x,N),fspace,scoord);   % rough guess for actions at evaluation points
      end
      [v,x] = vmax(s,x,c,fspace,model,F,G);                 % values and actions at evaluation points
    else
      [ss,xx]=gridmake(s,X);
      v = valfunc(c,fspace,ss,xx,e,delw,func,params);
      [v,j] = max(reshape(v,size(s,1),size(X,1)),[],2); % values and actions at evaluation points
      x = X(j,:);
    end
    resid = v-funeval(c,fspace,scoord);   % residual at evaluation points
    v_estimatedbymodel=funeval(c,fspace,scoord);
    resid = reshape(resid,[n 1]);         % reshape residual for plotting
  end
    
% RESHAPE OUTPUT
  switch algorithm
  case 'finite' 
    x = squeeze(xx);
    v = vv;
    c = cc;
  otherwise
    x = reshape(x,[n dx]); 
    v = reshape(v,[n  1]);
  end
  
    
% VMAX - Solves Bellman Equation
  function [v,x,vc] = vmax(s,x,c,fspace,model,F,G,X,maxn)
  % CONTINUOUS ACTIONS
  if isempty(F)
    % SET CONVERGENCE PARAMETER DEFAULTS
    tol           = optget('dpsolve_vmax','tol',5e-8);
    maxit         = optget('dpsolve_vmax','maxit',50);
    maxbacksteps  = optget('dpsolve_vmax','maxbacksteps',0);
    lcpmethod     = optget('dpsolve_vmax','lcpmethod','minmax');

    e=model.e;
    delw = model.discount*model.w;
    func=model.func;
    params=model.params;
    
    if isempty(x) % explict solution to control available
      dv=squeeze(funeval(c,fspace,s,eye(size(s,2))));
      x=feval(func,'x',s,dv,[],params{:});
      v = valfunc(c,fspace,s,x,e,delw,func,params);
    else
      % COMPUTE BOUNDS      
      [xl,xu] = feval(func,'b',s,x,[],params{:}); 

      % SOLVE FIRST ORDER CONDITIONS
      for it=1:maxit
        [v,vx,vxx] = valfunc(c,fspace,s,x,e,delw,func,params);
        [vx,deltax] = lcpstep(lcpmethod,x,xl,xu,vx,vxx);
        err = max(abs(vx),[],2);
        if all(err<tol), break, end;
        eold = inf;
        if maxbacksteps<1
          x = x+deltax;
        else
          for k=1:maxbacksteps
            xnew = x + deltax;
            [v,vx] = valfunc(c,fspace,s,xnew,e,delw,func,params);
            vx = lcpstep(lcpmethod,x,xl,xu,vx);
            enew = max(abs(vx),[],2);
            ind = find(eold>enew & enew>err);
            if isempty(ind), break; end
            eold = enew;
            deltax(ind,:) = deltax(ind,:)/2;
          end 
          x = xnew;
        end
      end
    end

    % COMPUTE dv/dc %%%%%I did not adapt this
    if nargout>2 %only used for Newton, not used for function iteration where nargout=2 and residual where nargout=2
      ns = size(s,1);
      g = feval(func,'g',s,x,e(ones(ns,1),:),params{:});
      vc = delw(1)*funbasxFV(fspace,g,[],'completeChebyshev',maxn).vals{1}; %funbas(fspace,g); 
      for k=2:length(delw)
        g = feval(func,'g',s,x,e(k+zeros(ns,1),:),params{:});
        vc = vc + delw(k)*funbasxFV(fspace,g,[],'completeChebyshev',maxn).vals{1};%funbas(fspace,g);
      end
    end
  % DISCRETE ACTIONS
  else
    [ns,nc] = size(G);
    nx = length(model.actions);
    ns = ns/nx;
    [v,j] = max(reshape(F+G*c,ns,nx),[],2);
    x = X(j,:);
    if nargout>2
      i = (j-1)*ns + (1:ns)';   
      vc = reshape(G(i,:),ns,nc);
    end
  end
  
 
% VALFUNC  Evaluates Bellman Optimand
  function [v,vx,vxx]=valfunc(c,fspace,s,x,e,delw,func,params);
  discount=cell2mat(params(end)); %%%Epstein-Zin%%%
  p=(1-cell2mat(params(end-2)))/(1-cell2mat(params(end-1))); %%%Epstein-Zin%%%
  eta=cell2mat(params(end-2));
  % COMPUTE LOCAL CONSTANTS
    [ns,ds] = size(s);
    dx  = size(x,2);
    dxx = dx*dx;
    K = length(delw);

    if nargout<2 
      v = feval(func,'f',s,x,[],params{:});
      f=v; %%%Epstein-Zin%%%
      for k=1:K
        kk = k + zeros(ns,1); 
        g = feval(func,'g',s,x,e(kk,:),params{:});
        v  = v  + delw(k)/discount*((1-eta).*funeval(c,fspace,g)).^(1/p);%%%Epstein-Zin%%%
      end
      v=f+discount*(v-f).^p ;%%%Epstein-Zin%%%
    elseif nargout<3 
      [v,vx] = feval(func,'f',s,x,[],params{:});
      vx = reshape(vx,ns,1,dx);
      f=v;fx=vx; %%%Epstein-Zin%%%
      for k=1:K
        kk = k + zeros(ns,1); 
        [g,gx] = feval(func,'g',s,x,e(kk,:),params{:});
        [vnext,vs] = fund(c,fspace,g,1);
        %old: v  = v  + delw(k)*vnext;
        v   = v   + delw(k)/discount.*((1-eta)*vnext).^(1/p);%%%Epstein-Zin%%%
        % old: vx = vx + delw(k)*arraymult(vs,gx,ns,1,ds,dx);
        vx  = vx  +delw(k)/discount.*((1-eta)*vnext).^(1/p-1).*(1-eta).*arraymult(vs,gx,ns,1,ds,dx); %%%Epstein-Zin%%%
      end
      vEZ=f+discount*(v-f).^p; %%%Epstein-Zin%%%
      vx=fx+discount*(v-f).^(p-1).*(vx-fx); %%%Epstein-Zin%%%
      clear g gx 
      v=vEZ;
      vx = reshape(vx,ns,dx);
    else 
      [v,vx,vxx] = feval(func,'f',s,x,[],params{:});
      vx  = reshape(vx,ns,1,dx);
      vxx = reshape(vxx,ns,dx,dx);
      f=v;fx=vx;fxx=vxx;
      for k=1:K
        kk = k + zeros(ns,1);
        [g,gx,gxx] = feval(func,'g',s,x,e(kk,:),params{:});
        [vnext,vs,vss] = fund(c,fspace,g,1);
        v   = v   + delw(k)/discount.*((1-eta)*vnext).^(1/p); %%%Epstein-Zin%%%
        %vx  = vx  +delw(k)/discount.*vnext.^(1/p-1).*arraymult(vs,gx,ns,1,ds,dx); %%%%Epstein-Zin%%%complex intermediary results
        vx  = vx  +delw(k)/discount.*((1-eta)*vnext).^(1/p-1).*(1-eta).*arraymult(vs,gx,ns,1,ds,dx);
        vxx = vxx + delw(k)/discount.*((1/p-1).*((1-eta)*vnext).^(1/p-2).*((1-eta).*arraymult(vs,gx,ns,1,ds,dx)).^2 ...
          + ((1-eta)*vnext).^(1/p-1).*(1-eta).*(reshape(arraymult(vs,gxx,ns,1,ds,dxx),ns,dx,dx) ...
          + arraymult(permute(gx,[1 3 2]),arraymult(vss,gx,ns,ds,ds,dx),ns,dx,ds,dx))); %%%Epstein-Zin%%%
        if isreal(vx)==0      
            vxcomplex=vx; end
        if isreal(vxx)==0 
            vxxcomplex=vxx; end
      end
      vEZ=f+discount/(1-eta)*(v-f).^p; %%%Epstein-Zin%%%
      %vx=fx+discount/(1-eta)*(v-f).^(p-1).*(1-eta).^(1/p).*(vx-fx); %%%Epstein-Zin%%% complex intermediary restuls
      vxEZ=fx+discount/(1-eta)*(v-f).^(p-1).*(vx-fx);
      vxxEZ=fxx+discount/(1-eta)*(p-1)/p.*(v-f).^(p-2).*(vx-fx).^2 + discount/(1-eta)*(v-f).^(p-1).*(vxx-fxx); %%%Epstein-Zin%%%
      clear g gx gxx vss
      v   = vEZ;
      vx  = reshape(vxEZ,ns,dx);
      vxx = reshape(vxxEZ,ns,dxx);
    end

  
% GETFG - Computes Reward and Discounted Expected Basis for Discrete Choice Models
  function [F,G,X] = GetFG(s,fspace,model)
  
  if ~isfield(model,'actions'), F=[];G=[]; X=[]; return; end

  e = model.e;
  delw = model.discount*model.w;
  func=model.func;
  params=model.params;

  K = length(delw);
  X = gridmake(model.actions);
  [ss,xx] = gridmake(s,X);
  ns=size(ss,1);
  
  F = feval(func,'f',ss,xx,[],params{:});
  g = feval(func,'g',ss,xx,e(ones(ns,1),:),params{:});
  G=delw(1)*funbas(fspace,g);
  for k=2:K
    g = feval(func,'g',ss,xx,e(k + zeros(ns,1),:),params{:});
    G = G + delw(k)*funbas(fspace,g);
  end    