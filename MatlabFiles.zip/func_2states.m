function [out1,out2,out3]=func_2states(flag,s,x,e,A0,L0,g,alpha,phi,varphi,gamma,delta,eta,RRA,discount)
%x=decision variables=[emissions, investments]
%s=state variables=[cumulative emissions, capital]
%e=stochastic component of emissions (brownian motion on S)

[~,ds]=size(s);                             %ds is number of states 
[n,dx]=size(x);                             %dx is number of decisions
y=A0*s(:,2).^alpha.*exp(phi*x(:,1)-varphi/2*x(:,1).^2-gamma/2*s(:,1).^2);%production per unit of effective labour
c=y-x(:,2);                                 %Consumption is production minus investment

switch flag
    case 'b'                                %constraints on decision variables
        out1=[zeros(n,1),     zeros(n,1)];  %lower bounds on emissions and investments
        out2=[ones(n,1)*40,   ones(n,1)*50];% upper bounds on emissions and investments
    case 'f'
        out1=1/(1-eta)*c.^(1-eta) ;         %Objective function
        out2=zeros(n,dx);                   %First derivatives wrt decision variables
        out2(:,1)=c.^(-eta).*y.*(phi-varphi*x(:,1)) ;
        out2(:,2)=-c.^(-eta);
        out3=zeros(n,dx,dx);                %second derivatives wrt decision variables
        out3(:,1,1)=c.^(-eta).*y.*((1-eta./c.*y).*(phi-varphi*x(:,1)).^2 -varphi);
        out3(:,1,2)=eta.*c.^(-eta-1).*y.*(phi-varphi*x(:,1));
        out3(:,2,1)=out3(:,1,2);
        out3(:,2,2)=-eta.*c.^(-eta-1) ;
    case 'g'
        out1=[x(:,1)+s(:,1)+e , x(:,2)+(1-delta-g)*s(:,2)];%Equation of motion
        out2=zeros(n,ds,dx);                %First derivatives wrt decision variable
        out2(:,1,1)=ones(n,1);
        out2(:,2,2)=ones(n,1);
        out3=zeros(n,ds,dx,dx);             %Second derivatives wrt decision variable
end  