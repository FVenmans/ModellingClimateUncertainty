%Collocation method
clear; close all; 
format shortG %different short format for each number in a vector. Useful for snmax and snmin output from dpsolve
compeconpath='C:\Users\frank\Google Drive\Google Research Rest\MATLAB\compecon\'; 
path([compeconpath 'CEtools;' compeconpath 'CEdemos'],path);
%slow execution of code in the past: because \\umons.ac.be instead of C:\
%To increase speed first time you use compecon: home=>add-Ons => install MinGW-w64  => mexall
%ALGORTIHM OPTIONS (will also apply to dpsolveEZ)
    optset('dpsolve','showiters',1);
    optset('dpsolve','algorithm','funcit'); %default is 'newton', which is faster but less stable 
    nres=1; optset('dpsolve','nres',nres); %default 10. better graphs with 10 but longer runs
    optset('dpsolve','maxit',3000); %default 500   
    optset('dpsolve_vmax','maxit',50); %default 50 
    optset('dpsolve','tolfuncit',1e-4); %default 1e-4 %tolerance level to switch from funcit to newton
%DEFINE PARAMETERS
    eta=1.35;
    g=[0.02 0.0042 0.015 0.01 0.0037 0.74 0.01]; % g g_L g_tau g_psi g_A1 g_varphi g_A2; g_A1 compensates jump effect;g_A2 is OrnsteinUhlenbeck on A ( g+g_L-g_psi=g_tau)
    %for tau_max 0.8 => tau=[0.03 .24 .55 .77]. For g_tau=.015=>t=[2 19 54 98].
    rho=0.011;
    discount=exp(-(rho-g(2)+(eta-1)*g(1)));
    RRA=4; %relative risk aversion for Epstein-Zinn
%Production
    A0=3.44;% GDP0/L0/(kd0+kc0)^0.3 GDP 2020=84.5 Trillion$  
    L0=7.795; % popuation in 2020 UN world population prospects (dice has 7.403)
    alpha=0.3; %elasticity of capital in Cobb-Douglas
    psi0=2; %GtCO2/trillion_brown_capital/year: 50GtCO2/20trillion =2.5tCO2/1000$ capital
    E0=56; 
    kd0=E0/psi0/L0; %gives 56GtCO2 emissions in 2020 
    kc0=280/L0;% 36.000$/cap. DICE has 223 trillion initial capital, I need to stay close to steady state
    delta=[0.04 0.04]; %DICE has 0.1
    chi=[0.1 0.1]; %parameter for quadratic investment costs
    theta=[705 2.1];%in former runs we used theta1*L0*.^(theta(2)-1)=16.3, now theta1/k=15.2;      %coefficient on stranded assets term; power of stranded assets term in consumption; 
%Abatement function
    varphi=4e-5; %4.2e-5 in main analysis  %0.00003 in DietzVenmans, Higher due to 1% decrease per year
    phi=60*varphi; %=60*varphi Assumes 60GtCO2 BAU emissions   48GtCO2 mean in IPCC scenarios in 2010 and 2015
    beta=[100 0.1 0.4 0];  % endogenous learning parameters. Cumulative abatement at start (M0); power (epsilon); weighting (omega;0=exogenous; 1=endogenous); %loss for ZE production in Abat function is used
%damage function
    zeta=0.0006; 
    gammaT=[0.0077 0 0] ; %gamma in paper=0.0077*2=0.0154; Results in 6.7% damage at 3°C as in Howard and Sterner, plus 20%*(0.07*3°C)*0.017=0.071% mean effect via the jumps on tfp, which is too low. DietzVenmans has 0.01 as central value, Dice has 0.005
    gamma=zeta^2*gammaT(1)*2; % gamma =zeta²gamma in paper (includes TCRE).
    %damage function 2°C CostBenefit (same damage before 2°C
        damage2_3CB=[0.042 0.0435 0.045 0.0465 0.048 0.049];
        for i=1:6 % i use i=1 in the final optimization to obtain a similar steady state temperature.
            damage_2CB(i,:)=[gammaT(1)*(0:0.1:2).^2 damage2_3CB(i)];
            gammaT2CB(i,:)=polyfit([(0:0.1:2) 2.3],damage_2CB(i,:),6);
        end
        PlotDamageFunction(gammaT,gammaT2CB)
    %damage function 2°C CostEffectiveness (no damages before 2°C)   
        scale=[1 0.85 0.7 0.55 0.4 0.3 0.2 0.1];
        damage2_3CE=[0.042 0.042 0.042 0.042 0.041 0.040 0.037 0.035];
        for i=1:8
            damage_2CE(i,:)=[gammaT(1)*scale(i)*(0:0.1:1.7).^2 damage2_3CE(i)];
            gammaT2CE(i,:)=polyfit([(0:0.1:1.7) 2.3],damage_2CE(i,:),6);
        end
        %PlotDamageFunction(gammaT,gammaT2CE)
        %compare both damage functions at 2°C constraint 
        %figure();plot((0:0.1:2.5),gammaT(1)*(0:0.1:2.5).^2,linspace(0,2.5),polyval(gammaT2CE(8,:),linspace(0,2.5)),linspace(0,2.5),polyval(gammaT2CB(2,:),linspace(0,2.5)));
    %damage function 1.5°C starting from 2°C damage 
        scale=  [0.95 0.91 0.88 0.85 0.83 0.81 0.79 0.77 0.76] ; 
        for i=1:9
            gammaT15CE(i,:)=polyfit([(0:0.1:1.7) 2.3]*scale(i),damage_2CE(8,:),6);
        end 
        %PlotDamageFunction(gammaT,gammaT15CE)
%UNCERTAINTY    
    Sigma=diag([1e-4 1e-4 9e-4 1e-4]); %variance of kd,kc,S,A %1e-4 Capital 11% chance of a shock of 1.7% on a year. 9e-4 Brownian motion on S fits the IPCC Temp range for 2080-2100for RCP's; brownian motion on A from Barro.
    Sigma(1,2)=0.5*(Sigma(1,1)*Sigma(2,2))^0.5; %correllation=0.5
    Sigma(2,1)=Sigma(1,2);
    nshocks=[3 3 3 3];% set to 3 3 3 to increase speed 
    [eBrownian,wBrownian]=qnwnorm(nshocks,[0 0 0 0],Sigma); 
    % to make prob dependent on state: change delw in dpsolve on line 289-292 and in function valfunc 
    lambdaA=0.017;
    xi1=0.20;
    xi2=0.07; %2°C extra increases the size of the shock by 2*xi2%, i.e. 21.4% loss instead of 20% loss for a disaster
    e=[eBrownian zeros(size(eBrownian,1),1);[0 0 0 0] xi1]; % no other stochastics in a year with a jump.
    w=[wBrownian*(1-lambdaA);lambdaA];
    g(5)=w'*e(:,5).*(1+xi2)+Sigma(4,4)/2; %g(5) compensates mean effect of shocks, if not steady state of tfp is extremely low.
%INITIAL GUESS  FOR STEADY STATE (for LINEAR QUADRATIC APPROXIMATION)
    Sstar= (rho-g(2)+(eta-1)*g(1))*phi/gamma/(1+g(6)); % Due to learning, reduced by factor 1+g_phi, also reduces by disaster
    Tstar=Sstar*zeta; %1.94°C; 1.3°C in lqapprox due to disasters, smax 2.2°C 
    kcstar=(A0*exp(-gamma/2*Sstar^2)*alpha/((rho+delta(2)+eta*g(1))))^(1/(1-alpha)) ; %http://www.econ2.jhu.edu/people/ccarroll/Public/LectureNotes/Growth/RamseyCassKoopmans.pdf A in their paper is A^(1/(1-alpha) in my notation
    estar=[0 0 0 0 0];
    sstar=[-1e-10,kcstar-2,Sstar-100,0.99,0.98];
    xstar=[-0.05 2.9];
    pstar=[-3e-5 0.06 -0.001 27 0]; %last element is 0.4 if exp(-0.5varphi*a²) is used
%MAKE GRID snodes
    S0=1.2/zeta; %1.2°C in 2020
    smin=[-1      35    S0        0.65   0]; % kmin 35 kmax 67 if exp(phiE-0.5vaphiE²); try 30 65 if exp(-0.5varphi*a²)
    smax=[E0*0.97 65    Sstar+300 1.2   0.75];%kcmax 67? could be lower, but no convergence;%MaxS should be close to Sstar, because else E_t+1 goes below Emin   
    n=[6 4 4 4 5]; %53434 is good. Does not work: 63433 63434 53435; alternatives: 53433 (kink in emissions);
    maxn=10; %if 9 and emissions has 5 nodes, the fifth power of emissions is not combined with any other dimension 
    fspace=fundefn('cheb',n,smin,smax); %alternative spli/cheb
    fspace1=fspace;
    scoord=funnode(fspace);
    snodes=gridmake(scoord);
    %snodes(:,1)=snodes(:,1)./(1+snodes(:,5)/2); No convergence for RRA=4
    %b=[-0.15 1.1 1.5 1.1 5.5 4.5;0 0.5 0.5 0.4 0.71 0]; %  idmin icmin idmax idmax_highkc icmax icmax_highkc; e_reductions 
    b=[-0.15 1 1.5 1.1 5.5 4.5;0 0.5 0.5 0.4 0.71 0]; %  idmin icmin idmax idmax_highkc icmax icmax_highkc; e_reductions 
%DEFINE MODEL    
    model.func='f5_EkSAtauLearn'; 
    model.discount=discount; 
    model.e=e;
    model.w=w;
%DEFINE SCENARIOS
    scenarioTitle={'Expected utility','Epstein Zin RRA=4','Epstein Zin RRA=6','No stranding costs','Abatement costs (instead of kd productivity gains)', ...
        'lower eta','Endogenous Learning','No stranding allowed', ...
        '2°C Cost-Effectiveness EU','2°C Cost-Effectiveness EU starting in 2030','2°C Cost-Effectiveness  EZ','2°C Cost-Effectiveness EZ starting in 2030', ...
        '1,5°C Cost-Effectiveness  EU','1,5°C delay until 2030',...
        '1,5°C delay until 2023','1,5°C delay until  2026','1,5°C delay until  2029','1,5°C delay until  2032',... %sc15-sc18
        'Cost-benefit delay until 2023','Cost-benefit delay until  2026','Cost-benefit delay until  2029','Cost-benefit delay until  2032',... %sc19-sc22
        'Exogenous Learning','No Learning MAC of 2020','No Uncertainty','2°C Cost-Benefit EU','2°C Cost-Benefit EZ','No learning No inertia No uncertainty'}; %sc23-sc27
    nstr=num2str(n);
    runTitle=['_' nstr(~isspace(nstr)) 'nonAbat']; 
for sc=3:28  
    sc
%EXPECTED UTILITY
if sc==1 
    %START WITH MODEL WITH EXOGENOUS LEARNING ONLY
         model.params={A0,L0,g,alpha,phi,psi0,varphi,gammaT,xi2,zeta,delta,theta,chi,[beta(1:2) 0 0],b,snodes,'learn',eta,RRA,discount};
            %If f5_EkSAtauLearnAbat: START WITH MODEL WITH LESS LEARNING, but S*below Smax, lower kmin to 30, but no convegence
            %model.params={A0,L0,[g(1:5) 0.4 g(7)],alpha,phi,psi0,varphi,gammaT,xi2,zeta,delta,theta,chi,[beta(1:2) 0],b,snodes,'learn',eta,RRA,discount};
    %CHECK MODEL DERIVATIVES AT THE STEADY STATE
         err=dpcheck(model,sstar,xstar,estar);
     %LINEARQUADRATIC APPROXIMATION (exogenous learning only)
        [vlq,xlq,plq,ss,xx,pp]=lqapprox(model,snodes,sstar,xstar,pstar); %the book has estar as last element, this is wrong 
     % SOLVE BELLMAN EQUATION   
        [c,s,v,x,v_init1,x_init1,resid,fspace1,~]=dpsolve_sminmaxn(model,smin,smax,n,vlq,xlq,maxn,'EU','funcit');
        c23=c;s23=s;x23=x; % for run on 100% exogenous learning
    %ADD ENDOGENOUS LEARNING
        for i=[0.1:0.1:beta(3)];i
            model.params={A0,L0,g,alpha,phi,psi0,varphi,gammaT,xi2,zeta,delta,theta,chi,[beta(1:2) i 0],b,snodes,'learn',eta,RRA,discount};       
            [c,s,v,x,v_init1,x_init1,resid,fspace1,~]=dpsolve_sminmaxn(model,smin,smax,n,v_init1,x_init1,maxn,'EU','newton');
        end         
        c1=c;s1=s;x1=x;
        %finer grid : %54444 convergence for Amax below 1.08 and kmax55 %[6 4 4 3 5]slightly worse      [5 4 4 3 5] worse
%             n_new=[5 3 4 3 4];
%             [c,s,v,x,v_init,x_init,resid,fspace]=dpsolve_newsnodes(model,smin,smax,n_new,smin,smax,n,c1,s1,x1,maxn,'EU','funcit');
%             c1_2=c;s1_2=s;x1_2=x;
end
%EPSTEIN ZINN
if sc==2    
    v_init2=v_init1;x_init2=x_init1;
    for RRA_gradual=[1.5 1.9 2.5 3 3.5 RRA] %1.5 2 3
        RRA_gradual
        model.params={A0,L0,g,alpha,phi,psi0,varphi,gammaT,xi2,zeta,delta,theta,chi,beta,b,snodes,'learn',eta,RRA_gradual,discount};       
        if RRA_gradual<=RRA;[c,s,v,x,v_init2,x_init2,resid,~,~]=dpsolve_sminmaxn(model,smin,smax,n,v_init2,x_init2,maxn,'EZ','newton');
        else;               [c,s,v,x,v_init2,x_init2,resid,~,~]=dpsolve_sminmaxn(model,smin,smax,n,v_init2,x_init2,maxn,'EZ','funcit');end
    end 
    c2=c;s2=s;x2=x;
%     n_new=[6 3 4 3 4];
%     [c2,s2,v,x2,v_init,x_init,resid,fspace2]=dpsolve_newsnodes(model,smin,smax,n_new,smin,smax,n,c2,s2,x2,maxn,'EZ','funcit');
end
if sc==3  %RRA=6    
    v_init3=v_init2;x_init3=x_init2;
    for RRA_high=[4.5 4.9 5.3 5.7 6] 
        RRA_high
        model.params={A0,L0,g,alpha,phi,psi0,varphi,gammaT,xi2,zeta,delta,theta,chi,beta,b,snodes,'learn',eta,RRA_high,discount};       
        if RRA_high<=6;[c,s,v,x,v_init3,x_init3,resid,~,~]=dpsolve_sminmaxn(model,smin,smax,n,v_init3,x_init3,maxn,'EZ','newton');
        else;          [c,s,v,x,v_init3,x_init3,resid,~,~]=dpsolve_sminmaxn(model,smin,smax,n,v_init3,x_init3,maxn,'EZ','funcit');end
    end 
    c3=c;s3=s;x3=x;
end
%ABATEMENT COSTS INSTEAD OF K_d PRODUCTIVITY GAINS (PRICE DECOMPISTION) 
if sc==5
    v_init5=v_init2;x_init5=x_init2;
    model.func='f5_EkSAtauLearnAbat';    
    for i=0:0.01:0.07
        i
        smin5=smin+[0 -40*i 0 0 0];%decrease k by 2.8
        %smax5=smax+[0 -40*i 0 0 0];
        model.params={A0,L0,g,alpha,phi,psi0,varphi,gammaT,xi2,zeta,delta,theta,chi,[beta(1:3) i],b,snodes,'learn',eta,RRA,discount};       
        if i<=0.07;[c,s,v,x,v_init5,x_init5,resid,~,~]=dpsolve_sminmaxn(model,smin5,smax5,n,v_init5,x_init5,maxn,'EZ','newton');
        else;      [c,s,v,x,v_init5,x_init5,resid,~,~]=dpsolve_sminmaxn(model,smin5,smax5,n,v_init5,x_init5,maxn,'EZ','funcit');end
    end
    c5=c;s5=s;x5=x;
%     n_new=[6 3 4 3 4];
%     [c5,s5,v,x5,v_init5,x_init5,resid,fspace5]=dpsolve_newsnodes(model,smin5,smax5,n_new,smin5,smax5,n,c5,s5,x5,maxn,'EZ','funcit');
end
%NO LEARNING 2060 (challenging because value function is independent of t)
% if sc==6 
     varphiNL=3.2e-5; %best fit without learning,  coincides in 2060
%     phiNL=60*varphiNL;
%     SstarNL2060= (rho-g(2)+(eta-1)*g(1))*phiNL/gamma-900;% -900 due to decreasing carbon intensity?
%     sstarNL2060=sstar; sstarNL2060(3)=SstarNL2060;
%     smax6=[E0*0.97 67    SstarNL2060 1.2   0.75]; 
%     fspace6=fundefn('cheb',n,smin,smax6);scoord=funnode(fspace6);snodes6=gridmake(scoord);snodes6(:,1)=snodes6(:,1)./(1+snodes6(:,5));
%     model.params={A0,L0,g,alpha,phiNL,psi0,varphiNL,gammaT,gammaA,zeta,delta,theta,chi,beta,b,snodes6,'nolearn',eta,RRA,discount};
%     [vlq,xlq,plq,ss,xx,pp]=lqapprox(model,snodes6,sstarNL2060,xstar,pstar);
%     [c,s,v,x,v_init5,x_init5,resid,fspace6,snodes6]=dpsolve_sminmaxn(model,smin,smax6,n,vlq,xlq,maxn,'EU','funcit');
%    c6=c;s6=s;x6=x;
% end
%ETA 1.05 
if sc==6  
    model.func='f5_EkSAtauLearn';
    v_init6=v_init2;x_init6=x_init2;
    for eta_low=[1.33 1.30 1.28 1.25 1.225 1.20 1.175 1.15 1.125 1.10 1.075 1.05] 
        eta_low
        model.params={A0,L0,g,alpha,phi,psi0,varphi,gammaT,xi2,zeta,delta,theta,chi,beta,b,snodes,'learn',eta_low,RRA,discount};       
        if eta_low>0;[c,s,v,x,v_init6,x_init6,resid,~,~]=dpsolve_sminmaxn(model,smin,smax,n,v_init6,x_init6,maxn,'EZ','newton');
        else;        [c,s,v,x,v_init6,x_init6,resid,~,~]=dpsolve_sminmaxn(model,smin,smax,n,v_init6,x_init6,maxn,'EZ','funcit');end
    end 
    c6=c;s6=s;x6=x;
end 

%ENDO LEARNING
if sc==7 
        v_init7=v_init1;x_init7=x_init1;
        optset('dpsolve','tolfuncit',1e-5);
    for i=[0.45:0.05:1] 
        i
        model.params={A0,L0,g,alpha,phi,psi0,varphi,gammaT,xi2,zeta,delta,theta,chi,[beta(1:2) i 0],b,snodes,'learn',eta,RRA,discount};       
        if i<=1;  [c,s,v,x,v_init7,x_init7,resid,~,~]=dpsolve_sminmaxn(model,smin,smax,n,v_init7,x_init7,maxn,'EU','newton');
        else;     [c,s,v,x,v_init7,x_init7,resid,~,~]=dpsolve_sminmaxn(model,smin,smax,n,v_init7,x_init7,maxn,'EU','funcit');end
    end 
    c7=c;s7=s;x7=x;
    figure()
    plot([2020:2100], varphi./(1+g(6)*(1-exp(-g(3)*[0:80]))), ...
        [2020:2100],varphi*((beta(1)+phi./varphi.*[0:80]+2000-s3path(2,:))./beta(1)).^-beta(2),...
        [2020:2100],varphiNL*ones(1,81)); %[2020:2100],1./(1+g(6)*(1-exp(-g(3)*10*ones(1,81))))
        legend('exogenous learning','endogenous learning','no learning')
        title('varphi')
end
%NO STRANDING ALLOWED
if sc==8 
    b8=b;v_init8=v_init2;x_init8=x_init2;
    for i=[-0.1:0.05:0]
    b8(1,1)=i;
    model.params={A0,L0,g,alpha,phi,psi0,varphi,gammaT,xi2,zeta,delta,theta,chi,beta,b8,snodes,'learn',eta,RRA,discount};
    [c,s,v,x,v_init8,x_init8,resid,~,~]=dpsolve_sminmaxn(model,smin,smax,n,v_init8,x_init8,maxn,'EZ','newton');    
    end
    c8=c;s8=s;x8=x;
end

%2°C COST EFFECTIVENESS EU
if sc==9 
    smax2deg=smax;smax2deg(3)=2.2/zeta;
    smin2deg=smin;
    optset('dpsolve','tolfuncit',1e-4);
    v_init9=v_init1;x_init9=x_init1;
    for i=1:8  
        i
        smin2deg(1)=smin(1)-i*0.03*L0*psi0;
        model.params={A0,L0,g,alpha,phi,psi0,varphi,gammaT2CE(i,:),xi2,zeta,delta,theta,chi,beta,b,snodes,'learn',eta,RRA,discount}; 
        [c,s,v,x,v_init9,x_init9,resid,fspace9,snodes9]=dpsolve_sminmaxn(model,smin2deg,smax2deg,n,v_init9,x_init9,maxn,'EU','funcit'); %EZ may work immediately
        %[c,s,v,x,v_init9,x_init9,resid,fspace9,snodes9]=dpsolve_newsnodes(model,smin,smax2deg,n2deg2,smin,smax,n2deg,c1,s1,x1,maxn,'EU','funcit');
    end
    s9=s;x9=x;c9=c;   
end
%2°C COST EFFECTIVENESS EZ (starting from EU)
if sc==11 
     x_init11=x_init9;
     v_init11=v_init9;
    for RRA_gradual=[1.5 2 3 4] 
        RRA_gradual 
        model.params={A0,L0,g,alpha,phi,psi0,varphi,gammaT2CE(end,:),xi2,zeta,delta,theta,chi,beta,b,snodes,'learn',eta,RRA_gradual,discount};
        if RRA_gradual<=4;  [c,s,v,x,v_init11,x_init11,resid,~,~]=dpsolve_sminmaxn(model,smin2deg,smax2deg,n,v_init11,x_init11,maxn,'EZ','newton');
        else ;              [c,s,v,x,v_init11,x_init11,resid,~,~]=dpsolve_sminmaxn(model,smin2deg,smax2deg,n,v_init11,x_init11,maxn,'EZ','funcit');
        end
    end
    c11=c;s11=s;x11=x;
end
%1.5°C COST EFFECTIVENESS (starting from 2°C limit) 
if sc==13
    smax15deg2=ones(9,1)*smax;
    %smax15deg2(:,3)=[2.1;1.9;1.8;1.75;1.7;1.65;1.65;1.60;1.55]/zeta; %model is very sensitive to state with high temp, because brownian motion adds 5% to temp, S will alwasy to 0.5°C beyond Smax
    smax15deg2(:,3)= [2.1;2;1.9;1.8;1.75;1.7;1.65;1.65;1.65]/zeta;
    %smin15deg=smin;smin15deg(1)=-0.14;
    b13=b;b13(1,1)=-0.2; % allow for faster speed of abatement  (2.8GtCO2 beyond decay) if highest gridpoint of S is beyond steady state. Neg Emission=id*psi*L0=-0.15*2*7.8=-2.3GtCO2
    v_init13=v_init9;x_init13=x_init9; 
    optset('dpsolve','tolfuncit',1e-5);
    for i=7:9
        i
        model.params={A0,L0,g,alpha,phi,psi0,varphi,gammaT15CE(i,:),xi2,zeta,delta,theta,chi,beta,b13,snodes,'learn',eta,RRA,discount}; 
        if i<=7;[c,s,v,x,v_init13,x_init13,resid,fspace13,snodes13]=dpsolve_sminmaxn(model,smin2deg,smax15deg2(i,:),n,v_init13,x_init13,maxn,'EU','newton');
        else;   [c,s,v,x,v_init13,x_init13,resid,fspace13,snodes13]=dpsolve_sminmaxn(model,smin2deg,smax15deg2(i,:),n,v_init13,x_init13,maxn,'EU','funcit');
        end
    end
    c13=c;s13=s;x13=x;
end
%NO LEARNING MAC of 2020
if sc==24
    %     via lqapprox does not work (value functin is independent of time).
    %alternative starting from model with learning and 
        v_init24=v_init1;x_init24=x_init1;
        for i=[0.9:-0.1:0.1] %no convergence for i=0 
            i           
           g24=g;g24(6)=g(6)*i;
           beta24=[beta(1:2) beta(3)*i 0];
           smax24=smax+[0 0 (1-i)*750 0 0]; %steady state is larger without learning (should increase by more than 500)
           model.params={A0,L0,g24,alpha,phi,psi0,varphi,gammaT,xi2,zeta,delta,theta,chi,beta24,b,snodes,'learn',eta,RRA,discount};       
           [c,s,v,x,v_init24,x_init24,resid,fspace24,snodes24]=dpsolve_sminmaxn(model,smin,smax24,n,v_init24,x_init24,maxn,'EU','newton');
        end
    c24=c;s24=s;x24=x;
end
%NO UNCERTAINTY
if sc==25
    v_init25=v_init1;x_init25=x_init1;
       for i=[0.95:-0.05:0]; i           
           model.e=e*i;
           g25=g;g25(5)=g(5)*i;
           smax25=smax+[0 0 (1-i)*400 0 0]; %500 in earlier model. steady state is larger without uncertainty. Does not work for Smax +600, weird
           model.params={A0,L0,g25,alpha,phi,psi0,varphi,gammaT,xi2,zeta,delta,theta,chi,beta,b,snodes,'learn',eta,RRA,discount};       
           if i>=0.55, [c,s,v,x,v_init25,x_init25,resid,fspace25,snodes25]=dpsolve_sminmaxn(model,smin,smax25,n,v_init25,x_init25,maxn,'EU','newton');
           else [c,s,v,x,v_init25,x_init25,resid,fspace25,snodes25]=dpsolve_sminmaxn(model,smin,smax25,n,v_init25,x_init25,maxn,'EU','funcit');end
       end  
    c25=c;s25=s;x25=x;
    %alternative, same result (check parameter beta, because lqapprox has difficulties with the steady state of endogenous learning
    %fspace=fundefn('cheb',n,smin,smax+[0 0 200 0 0]);scoord=funnode(fspace);snodes25=gridmake(scoord);    
    %[vlq,xlq,plq,ss,xx,pp]=lqapprox(model,snodes25,sstar,xstar,pstar);     
    %[c,s,v,x,v_init5,x_init5,resid,fspace]=dpsolve_sminmaxn(model,smin,smax+[0 0 200 0 0],n,vlq,xlq,maxn,'EU','funcit');   
%     n_new=[6 3 4 3 4];
%     [c25,s25,v,x25,v_init5,x_init5,resid,fspace25,snodes25]=dpsolve_newsnodes(model,smin,smax25,n_new,smin,smax25,n,c25,s25,x25,maxn,'EZ','funcit');
end
%2°C COST BENEFIT EU
if sc==26
    model.e=e; 
    v_init26=v_init1;x_init26=x_init1;
    for i=2 
        i;
        smin2deg(1)=smin(1)-i*0.04*L0*psi0; %change if number of steps change
        model.params={A0,L0,g,alpha,phi,psi0,varphi,gammaT2CB(i,:),xi2,zeta,delta,theta,chi,beta,b,snodes,'learn',eta,RRA,discount}; 
        if i<=3;[c,s,v,x,v_init26,x_init26,resid,fspace26,snodes26]=dpsolve_sminmaxn(model,smin2deg,smax2deg,n,v_init26,x_init26,maxn,'EU','newton');
        else   ;[c,s,v,x,v_init26,x_init26,resid,fspace26,snodes26]=dpsolve_sminmaxn(model,smin2deg,smax2deg,n,v_init26,x_init26,maxn,'EU','funcit'); end
    end
    s26=s;x26=x;c26=c;  
end
%2°C COST BENEFIT EZ
if sc==27
    optset('dpsolve','tolfuncit',1e-4);
    v_init27=v_init2;x_init27=x_init2;
    for i=2
        i
        smin2deg(1)=smin(1)-i*0.04*L0*psi0 ;
        model.params={A0,L0,g,alpha,phi,psi0,varphi,gammaT2CB(i,:),xi2,zeta,delta,theta,chi,beta,b,snodes,'learn',eta,RRA,discount}; 
        [c,s,v,x,v_init27,x_init27,resid,~,~]=dpsolve_sminmaxn(model,smin2deg,smax2deg,n,v_init27,x_init27,maxn,'EZ','newton'); 
    end 
    s27=s;x27=x;c27=c; 
end
%STRAW MAN: NO LEARNING 2030,NO UNCERTAINTY, NO INERTIA
if sc==28 % start from model 24 without learning (difficult because V is independent of time)
    v_init28=v_init24;x_init28=x_init24;
    varphi2030=varphi/(1+g(6)*(1-exp(-g(3)*10))); %3.8e-5;
    g28=g;g28(6)=0;
    for i=[0.95:-0.05:0]; i           
           model.e=e*i;
           g28(5)=g(5)*i;
           varphi28=varphi2030-i*(varphi2030-varphi);
           smax28=smax24+[0 0 (1-i)*0 0 0]; %steady state is larger without uncertainty (+400), but lower with lower varphi. 
           model.params={A0,L0,g28,alpha,60*varphi28,psi0,varphi28,gammaT,xi2,zeta,delta,theta,chi,beta24,b,snodes,'nolearn',eta,RRA,discount};       
           if i>=-0.001, [c,s,v,x,v_init28,x_init28,resid,fspace28,snodes28]=dpsolve_sminmaxn(model,smin,smax28,n,v_init28,x_init28,maxn,'EU','newton');
           else [c,s,v,x,v_init28,x_init28,resid,fspace28,snodes28]=dpsolve_sminmaxn(model,smin,smax28,n,v_init28,x_init28,maxn,'EU','funcit');end
       end  
    c28=c;s28=s;x28=x;
end
MeanAbsResidual(sc)=sum(abs(resid),'all')/n(1)/n(2)/n(3)/n(4)/n(5)/nres^5
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%GENERATE MONTE CARLO SIMULATION 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%increase the minimum of id to allow for negative emissions after brownian motion increases Temp by 5%
b_simul=b;b_simul(1,1)=-0.3;% id*psi*L0=-0.5*2*7.8=-7.8GtCO2
%make sure the correct parameters enter the simulation (in case the order of scenarios is customized)
    if sc==1;               c=c1;s=s1;x=x1;   fspace=fspace1 ;model.params={A0,L0,g,alpha,phi  ,psi0,varphi,  gammaT,             xi2,zeta,delta,theta,chi,beta,            b_simul,snodes ,'learn',eta,RRA,discount};      model.e=e;
    elseif sc==2||sc==4||(sc>=19&&sc<=22);
                            c=c2;s=s2;x=x2;   fspace=fspace1 ;model.params={A0,L0,g,alpha,phi  ,psi0,varphi,  gammaT,             xi2,zeta,delta,theta,chi,beta,            b_simul,snodes ,'learn',eta,RRA,discount};      model.e=e;
    elseif sc==3;           c=c3;s=s3;x=x3;   fspace=fspace1 ;model.params={A0,L0,g,alpha,phi  ,psi0,varphi,  gammaT,             xi2,zeta,delta,theta,chi,beta,            b_simul,snodes ,'learn',eta,RRA_high,discount}; model.e=e;
    elseif sc==5;           c=c5;s=s5;x=x5;   fspace=fspace1 ;model.params={A0,L0,g,alpha,phi  ,psi0,varphi,  gammaT,             xi2,zeta,delta,theta,chi,[beta(1:3) 0.07],b_simul,snodes ,'learn',eta,RRA,discount};      model.e=e;
    elseif sc==6;           c=c6;s=s6;x=x6;   fspace=fspace1 ;model.params={A0,L0,g,alpha,phi  ,psi0,varphi,  gammaT,             xi2,zeta,delta,theta,chi,beta,            b_simul,snodes ,'learn',eta_low,RRA,discount};  model.e=e;
    elseif sc==7;           c=c7;s=s7;x=x7;   fspace=fspace1 ;model.params={A0,L0,g,alpha,phi  ,psi0,varphi,  gammaT,             xi2,zeta,delta,theta,chi,[beta(1:2) 1 0], b_simul,snodes ,'learn',eta,RRA,discount};      model.e=e;
    elseif sc==8;           c=c8;s=s8;x=x8;   fspace=fspace1 ;model.params={A0,L0,g,alpha,phi  ,psi0,varphi,  gammaT,             xi2,zeta,delta,theta,chi,beta,            b8     ,snodes ,'learn',eta,RRA,discount};      model.e=e;
    elseif sc==9 || sc==10; c=c9;s=s9;x=x9;   fspace=fspace9 ;model.params={A0,L0,g,alpha,phi  ,psi0,varphi,  gammaT2CE(end,:),   xi2,zeta,delta,theta,chi,beta,            b_simul,snodes9,'learn',eta,RRA,discount};      model.e=e;
    elseif sc==11|| sc==12; c=c11;s=s11;x=x11;fspace=fspace9 ;model.params={A0,L0,g,alpha,phi  ,psi0,varphi,  gammaT2CE(end,:),   xi2,zeta,delta,theta,chi,beta,            b_simul,snodes9,'learn',eta,RRA,discount};      model.e=e;
    elseif sc>=13&&sc<=18;  c=c13;s=s13;x=x13;fspace=fspace13;model.params={A0,L0,g,alpha,phi  ,psi0,varphi,  gammaT15CE(end,:),  xi2,zeta,delta,theta,chi,beta,            b_simul,snodes13,'learn',eta,RRA,discount};     model.e=e;
    elseif sc==23;          c=c23;s=s23;x=x23;fspace=fspace1 ;model.params={A0,L0,g,alpha,phi  ,psi0,varphi,  gammaT,             xi2,zeta,delta,theta,chi,[beta(1:2) 0 0], b_simul,snodes ,'learn',eta,RRA,discount};      model.e=e;
    elseif sc==24;          c=c24;s=s24;x=x24;fspace=fspace24 ;model.params={A0,L0,g24,alpha,phi,psi0,varphi, gammaT,             xi2,zeta,delta,theta,chi,beta24,          b_simul,snodes24,'nolearn',eta,RRA,discount};   model.e=e;
    elseif sc==25;          c=c25;s=s25;x=x25;fspace=fspace25 ;model.params={A0,L0,g25,alpha,phi,psi0,varphi, gammaT,             xi2,zeta,delta,theta,chi,beta,            b_simul,snodes25,'learn',eta,RRA,discount};     model.e=e*0; 
    elseif sc==26;          c=c26;s=s26;x=x26;fspace=fspace26 ;model.params={A0,L0,g,alpha,phi  ,psi0,varphi, gammaT2CB(end,:),   xi2,zeta,delta,theta,chi,beta,            b_simul,snodes26,'learn',eta,RRA,discount};     model.e=e;
    elseif sc==27;          c=c27;s=s27;x=x27;fspace=fspace26 ;model.params={A0,L0,g,alpha,phi  ,psi0,varphi, gammaT2CB(end,:),   xi2,zeta,delta,theta,chi,beta,            b_simul,snodes26,'learn',eta,RRA,discount};     model.e=e;
    elseif sc==28;          c=c28;s=s28;x=x28;fspace=fspace28 ;model.params={A0,L0,g28,alpha,60*varphi28,psi0,varphi28,gammaT,    xi2,zeta,delta,theta,chi,beta24,          b_simul,snodes28,'nolearn',eta,RRA,discount};   model.e=e*0;    
    end   
%SET INITIAL CONDITIONS
    if          sc==10||sc==12||sc==14;start=2030;
        elseif  sc==15||sc==19;start=2023;
        elseif  sc==16||sc==20;start=2026;
        elseif  sc==17||sc==21;start=2029;
        elseif  sc==18||sc==22;start=2032;
        else;   start=2020; 
    end
    endyear=2100;
    nyrs=endyear-start;     
    nrep=5000;
    missing=[];
    if start~=2020, missing=ones(1,start-2020)*NaN;end
    if sc==4;           Sinit=[E0*0.5  kc0+kd0 S0+50*(start-2020) 1 1-exp(-g(3)*(start-2020))]; %start in 2020 with zero repurposing costs  
        elseif sc==28;  Sinit=[E0*0.45 kc0+kd0 S0+50*(start-2020) 1 1-exp(-g(3)*(start-2020))];    
        else;           Sinit=[E0      kc0+kd0 S0+50*(start-2020) 1 1-exp(-g(3)*(start-2020))]; 
    end
    sinit=Sinit(ones(nrep,1),:);
%MONTE CARLO
    %Difficult to write a function for all the monte carlo output: 22 output variables have to be written into variables with one line per scenario
    %(s1path,s2path,s3path,s4path,s5path,x1path,x2path,x1path_range,s1path_range,s3path_range,Epath,Epath_range,StrCostPath,StrCostPath_range,cpath,ypath,Tpath2300,dv_kcpath,Ppath,Ppath_range,vpath)MonteCarlo(sc,c,s,x,fspace,model,smaxMC,nrep,Sinit,delta
    [spath,xpath]=dpsimul(model,sinit,nyrs,s,x); 
    %set 2020 emissions for scenarios without inertia
    if sc==4||sc==28; spath(:,1,1)=E0;  xpath(:,1,1)=(spath(:,1,2)-spath(:,1,1).*(1-g(1)-g(2)-delta(1)))/L0/psi0  ;end

%EXCLUDE SCENARIOS TOO FAR OUTSIDE GRID (emissions <-6 in 2020 and -10 in 2100 ;Temp 20% outside grid; TA<0.65 )
    % figure();histogram(spath(:,3,81)*zeta,20);title('Temperature in 2100'); 
    % figure();histogram(spath(:,1,81),40);title('kd in 2100');    histogram(spath(:,1,81).*L0.*psi0*(2-exp(-g(3)*(0:80))));title('Emissions in 2100'); 
    %figure();histogram(xpath(:,1,81),40);title('id in 2100')
    %
    for i=1:nrep
        for j=1:nyrs+1
            if spath(i,1,j)<-20||spath(i,2,j)>1.3*fspace.b(2)||spath(i,2,j)<0.6*fspace.a(2)||spath(i,3,j)>1.2*fspace.b(3)||spath(i,3,j)<0.9*fspace.a(3)||spath(i,4,j)>1.2*fspace.b(4)||spath(i,4,j)<0.9*fspace.a(4) % Temp is only binding condition in central scenario (12 occurrences in 2100)
                %sum(spath(:,1,:)<-20,'all');sum(spath(:,2,:)>1.2*fspace.b(2),'all');sum(spath(:,2,:)<0.6*fspace.a(2),'all');
                %sum(spath(:,3,:)>1.2*fspace.b(3),'all');sum(spath(:,4,:)>1.2*fspace.b(4),'all');sum(spath(:,4,:)<0.9*fspace.a(4),'all');
                spath(i,:,j)=NaN; %[j:end] exculdes all observations following an exceedance 
                xpath(i,:,j)=NaN; 
            end
        end
    end
    PropDeleted(sc)=sum(isnan(spath),'all')/nrep/5/81 %sum(isnan(spath),[1 2])/nrep/5 %proportion deleted for each year
%MEAN SCENARIOS
    s1path(sc,:) =[missing, mean(squeeze(spath(:,1,:)),'omitnan')];
    s2path(sc,:) =[missing, mean(squeeze(spath(:,2,:)),'omitnan')];
    s3path(sc,:) =[missing, mean(squeeze(spath(:,3,:)),'omitnan')];
    s4path(sc,:) =[missing, mean(squeeze(spath(:,4,:)),'omitnan')];
    s5path(sc,:) =[missing, mean(squeeze(spath(:,5,:)),'omitnan')];
    x1path(sc,:) =[missing, mean(squeeze(xpath(:,1,:)),'omitnan')];
    x1pathmedian(sc,:) =[missing, median(squeeze(xpath(:,1,:)),'omitnan')];
    x2path(sc,:) =[missing, mean(squeeze(xpath(:,2,:)),'omitnan')];
%PERCENTILES
    x1path_range(sc,:,1)=[missing, prctile(squeeze(xpath(:,1,:).*(spath(:,1,:)>0)),10)];%set id to zero when emissions are negative, because neg emissions require negative investments that are not really stranded assets
    x1path_range(sc,:,2)=[missing, prctile(squeeze(xpath(:,1,:).*(spath(:,1,:)>0)),90)];%idential: xpath=sort(xpath);x1path_range2(sc,:,1)=[missing, squeeze(xpath(50,1,:))];
    s1path_range(sc,:,1)=[missing, prctile(squeeze(spath(:,1,:)),10)];
    s1path_range(sc,:,2)=[missing, prctile(squeeze(spath(:,1,:)),90)];
    s3path_range(sc,:,1)=[missing, prctile(squeeze(spath(:,3,:)),10)];
    s3path_range(sc,:,2)=[missing, prctile(squeeze(spath(:,3,:)),90)];
%OTHER PATHS
   [s1grid,s2grid,s3grid,s4grid,s5grid]=ndgrid(s{1},s{2},s{3},s{4},s{5}); %needed in loop 8 
    ResidPath(sc,:)=interpn(s1grid,s2grid,s3grid,s4grid,s5grid,resid,s1path(sc,:),s2path(sc,:),s3path(sc,:),s4path(sc,:),s5path(sc,:));
    Epath(sc,:)=s1path(sc,:);
    Epath_range(sc,:,:)=s1path_range(sc,:,:);
    StrCostPath(sc,:)=theta(1).*(-x1path(sc,:).*(x1path(sc,:)<0)).^theta(2).*L0.*exp((g(1)+g(2)).*(0:80)).*1000./s2path(sc,:);
    if sc==8||sc==4;StrCostPath(sc,:)=zeros(1,80+1);end
    StrCostPath_range(sc,:,:)=theta(1).*(-x1path_range(sc,:,:).*(x1path_range(sc,:,:)<0)).^theta(2).*L0.*exp((g(1)+g(2)).*cat(3,0:80,0:80)).*1000./s2path(sc,:);
    if sc==8||sc==4||sc==5;StrCostPath_range(sc,:,:)=zeros(1,80+1,2);end
    ypath      =A0.*(s1path(sc,:)./L0./psi0./(1+s5path(sc,:))+s2path(sc,:)).^alpha.*exp(phi.*exp(-0.01.*(0:80)).*Epath(sc,:)-varphi.*exp(-0.02.*(0:80))./2.*(Epath(sc,:)).^2-gamma/2.*s3path(sc,:).^2); %+beta*Edot 
    cpath=ypath-x1path(sc,:)-x2path(sc,:)-theta(1).*(x1path(sc,:).*x1path(sc,:)<0).^theta(2); %+beta*Edot %change 9 to 10  
    %MACpath(sc,:)= ypath*L0.*exp((g(1)+g(2)).*(0:80)).*(phi-varphi.*Epath(sc,:))*1000; %MAC is not carbon price, this calculation starts at zero if E0 is BAU 
%TEMPERATURE 2300
    nyrs2=nyrs+200;
    [spath2300,~]=dpsimul(model,sinit,nyrs2,s,x);
    Tpath2300(sc,:) =[missing, mean(squeeze(spath2300(:,3,:)))*zeta];
    clear spath2300
%CARBON PRICE 
    %v_kc=funeval(c,fspace,s,[0 1 0 0 0]);%derivative of value function with respect to clean capital
    %v_kc=reshape(v_kc,[length(s{1}), length(s{2}),length(s{3})]); 
    %v_kcpath(sc,:)=interpn(s1grid,s2grid,s3grid,v_kc,s1path(sc,:),s2path(sc,:),s3path(sc,:));
    dv_=funeval(c,fspace,s,[0 0 1 0 0;0 0 2 0 0; 0 0 3 0 0;1 0 1 0 0;0 1 1 0 0;2 0 1 0 0;0 2 1 0 0; 1 1 1 0 0;0 1 0 0 0;0 0 1 1 0;0 0 0 1 0;0 0 1 2 0;0 0 1 0 1]); %v_S v_SS v_SSS v_Skd v_Skc v_Skdkd v_Skckc v_Skdkc v_kc v_SA v_A v_SAA v_Stau
    dv_=reshape(dv_,[length(s{1}),length(s{2}),length(s{3}),length(s{4}),length(s{5}),13]);
    dv_path=zeros(13,80+1);
    for i=1:13
         dv_path(i,:)=interpn(s1grid,s2grid,s3grid,s4grid,s5grid,dv_(:,:,:,:,:,i),s1path(sc,:),s2path(sc,:),s3path(sc,:),s4path(sc,:),s5path(sc,:));
    end
    dv_kcpath(sc,:)=dv_path(9,:);
    dv_path(14,:)=interpn(s1grid,s2grid,s3grid,s4grid,s5grid,dv_(:,:,:,:,:,1),s1path(sc,:),s2path(sc,:),s3path(sc,:),s4path(sc,:).*(1-xi1),s5path(sc,:)); %V_S after jump on A.
    dv_path(15,:)=interpn(s1grid,s2grid,s3grid,s4grid,s5grid,dv_(:,:,:,:,:,11),s1path(sc,:),s2path(sc,:),s3path(sc,:),s4path(sc,:).*(1-xi1),s5path(sc,:)); %V_A after jump on A.

    Ppath(sc,:)=-dv_path(1,:)./dv_kcpath(sc,:).*L0.*exp((g(1)+g(2)).*(0:80))*1000; % according to Traeger. cpath.^-eta is very close to -v_kc
    %Correct way for p10 of carbon price is to integrate calculation of dv into dpsimul. Because high temp tends to correlate with high current emissions due to inertia. On the other hand high temp creates incentive for low emissions. 
    %I use mean emissions assuming that both effects cancel eachother. I could use p10 of lowest temperatures combined with p10 of lowest emissions. This would give a slight exageration of uncertainty. 
    %dvdS_low=interpn(s1grid,s2grid,s3grid,dv_(:,:,:,1),s1path(sc,:),s2path(sc,:),reshape(s3path_range(sc,:,1),[1,81]));
    Ppath_range(sc,:,1) =-interpn(s1grid,s2grid,s3grid,s4grid,s5grid,dv_(:,:,:,:,:,1),s1path(sc,:),s2path(sc,:),s3path_range(sc,:,1),s4path(sc,:),s5path(sc,:))./dv_kcpath(sc,:).*L0.*exp((g(1)+g(2)).*(0:80))*1000;%old error exp(g(1)+g(2).*(0:80))
    Ppath_range(sc,:,2) =-interpn(s1grid,s2grid,s3grid,s4grid,s5grid,dv_(:,:,:,:,:,1),s1path(sc,:),s2path(sc,:),s3path_range(sc,:,2),s4path(sc,:),s5path(sc,:))./dv_kcpath(sc,:).*L0.*exp((g(1)+g(2)).*(0:80))*1000;
%TOTAL WELFARE 
    vpath(sc,:)=interpn(s1grid,s2grid,s3grid,s4grid,s5grid,v,s1path(sc,:),s2path(sc,:),s3path(sc,:),s4path(sc,:),s5path(sc,:));
    % Vpath_Trdollars=vpath./dv_kcpath.*L0.*exp(g(1)+g(2).*(0:80));
%PLOTS
    PlotMeanScenarios(sc,Epath,x1path,L0,g,s1path,s2path,StrCostPath,s3path,Ppath,ResidPath,zeta,scenarioTitle,runTitle)
    %find((abs((scoord{1}(4)-s1path(sc,:)))<2)==1) %find year of 4th node of emissions % -1/g(3)*log(1-scoord{5});%find time nodes
    if sc==2||sc==5||sc==4||sc==11||sc==24||sc==25||sc==28;PriceDecomposition(s1path,s2path,s3path,s4path,s5path,x1path,x2path,dv_path,Epath,cpath,ypath,nyrs,L0,psi0,lambdaA,xi1,Sigma,chi,gamma,xi2,delta,g,rho,eta,zeta,phi,varphi,beta,sc,scenarioTitle);end
    if sc==2
        PlotDistribution(xpath,scenarioTitle(sc));
        PlotResiduals(smin,smax,n,nres,resid)
        [ClimateBeta,ClimateBetaMean]=climatebeta(spath,xpath,A0,L0,g,alpha,phi,psi0,varphi,gammaT,xi2,zeta,delta,theta,chi,beta) ;
    end
end
%TOTAL STRANDING AND COST
TotalStrCost=sum(StrCostPath,2, 'omitnan');
Stranding=-x1path(:,1:31).*L0.*exp((g(1)+g(2)).*(0:30))*1000.*(x1path(:,1:31)<0).*(s1path(:,1:31)>0);
TotalStranding=sum(Stranding,2, 'omitnan');
%SAVE DATA
if sc==28;save(['5states' runTitle '.mat']); end    %idem save(strcat('5states',runTitle,'.mat'))
%WELFARE COMPARISONS (this is imprecise because the exact level of the welfare function is difficult to estimate.
(vpath(2,13)-vpath(3,13))/dv_kcpath(2,2)*L0 % cost of 1 decade delay at current prices.
(vpath(2,3)-vpath(8,3))/dv_kcpath(2,2)*L0   % cost of avoiding stranding vs optimal stranding in 2020
%load('AveragedPaths') %E_path and x1_path and s3_path are mean paths

%GRAPHS COMPARING SCENARIOS
    AllGraphs               (Epath,Epath_range,x1path,x1path_range,s1path,s1path_range,s2path,s3path,s3path_range,Ppath,Ppath_range,StrCostPath,StrCostPath_range,L0,g,zeta,runTitle,scenarioTitle)
    TotalStrCost=sum(StrCostPath,2,'omitnan');
    Stranding=-x1path(:,1:31).*L0.*exp((g(1)+g(2)).*(0:30))*1000.*(x1path(:,1:31)<0).*(s1path(:,1:31)>0);
    TotalStranding=sum(Stranding,2,'omitnan');
    
    GraphCostDelayContinuous(Epath,x1path,s1path,s2path,s3path,Ppath,StrCostPath,L0,g,zeta,runTitle)
    GraphCB_2_15           (E_path,x1_path,s1path,s2path,s3_path,P_path,StrCostPath,L0,g,zeta,runTitle)
    GraphNoStrandingCosts  (E_path,E_path_range,x1_path,x1_path_range,s1path,s1path_range,s2path,s3_path,s3_path_range,P_path,P_path_range,StrCostPath,StrCostPath_range,L0,g,zeta,runTitle,'str')
    GraphNoStrandingCosts2030(E_path,E_path_range,x1_path,x1_path_range,s1path,s1path_range,s2path,s3_path,s3_path_range,P_path,P_path_range,StrCostPath,StrCostPath_range,L0,g,zeta,runTitle,'str')
    GraphCostOfDelay       (Epath,x1path,s1path,s2path,s3path,Ppath,StrCostPath,L0,g,zeta,runTitle,'str')
    GraphUncertainty        (E_path,E_path_range,x1_path,x1_path_range,s1path,s1path_range,s2path,s3_path,s3_path_range,P_path,P_path_range,StrCostPath,StrCostPath_range,L0,g,zeta,runTitle,'str')
    GraphUncertainty2deg2030(E_path,E_path_range,x1_path,x1_path_range,s1path,s1path_range,s2path,s3_path,s3_path_range,P_path,P_path_range,StrCostPath,StrCostPath_range,L0,g,zeta,runTitle,'str')
    GraphLearning        (E_path,x1_path,s1path,s2path,s3_path,P_path,StrCostPath,L0,g,zeta,runTitle,'str')
    %Graph2deg              (E_path,E_path_range,x1_path,x1_path_range,s1path,s1path_range,s2path,s3_path,s3_path_range,P_path,P_path_range,StrCostPath,StrCostPath_range,L0,g,zeta,runTitle,'str')
    %Graph15deg             (E_path,E_path_range,x1_path,x1_path_range,s1path,s1path_range,s2path,s3_path,s3_path_range,P_path,P_path_range,StrCostPath,StrCostPath_range,L0,g,zeta,runTitle,'str')
    %Graph2deg2030          (E_path,E_path_range,x1_path,x1_path_range,s1path,s1path_range,s2path,s3_path,s3_path_range,P_path,P_path_range,StrCostPath,StrCostPath_range,L0,g,zeta,runTitle,'str')
    %GraphA oidStranding2030(E_path,x1_path,s1path,s2path,s3_path,P_path,StrCostPath,L0,g,zeta,runTitle,'str')
    %GraphAllScenarios      (Epath,E_path_range,x1_path,x1_path_range,s1path,s1path_range,s2path,s3_path,s3_path_range,P_path,P_path_range,StrCostPath,StrCostPath_range,ResidPath,L0,g,zeta,runTitle)

