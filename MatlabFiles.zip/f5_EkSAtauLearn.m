function [out1,out2,out3]=f5_EkSAtauLearn(flag,s,x,e,A0,L0,g,alpha,phi,psi0,varphi,gammaT,xi2,zeta,delta,theta,chi,beta,b,sbounds,learn,eta,RRA,discount)
%Y_ZE is constant, learning reduces the extra productivity of emissions.V_t is negative.
%f5_EkSAtauLearnAbat is the opposite: Y_BAU is constant, learning reduces abatement costs and zero emission production. V_t is positive. Better, but not stable.

%x=dirty investments, clean investments
%s=emissions, total capital, cumulative emissions,total factor productivity, synthetic time
%e=brownian motion on Kd, brownian motion on Kc, brownian motion on S, brownian motion on A; jump on A
[~,ds]=size(s);
[n,dx]=size(x);
if size(e,1)~=n && ~isempty(e);e=e+zeros(n,1);end

switch flag
case 'b'
    out1=[ones(n,1)*b(1,1) , ones(n,1)*b(1,2)]; %lower bounds on x
    out2=[ones(n,1).*(b(1,3).*(s(:,2)<sbounds(2))+b(1,4).*(s(:,2)>=sbounds(2))) , ones(n,1).*(b(1,5).*(s(:,2)<63)+b(1,6).*(s(:,2)>=63))]; %upper bounds on x, stricter at highest nodes of kc
%limiting investment ouside the path, does not affect outcome, only more or less easy to converge.
%     min(x,[],[1 2 3 4 5])  % -0.28  1.53
%     max(x,[],[1 2 3 4 5])  % >1.4  5
%     min(xpath,[],[1 3]) %-0.21 2.63
%     max(xpath,[],[1 3]) % 0.08 3.67
%     min(spath,[],[1 3])
%     max(spath,[],[1 3])
case 'f'
    if strcmpi(learn,'learn')
        M=(beta(1)+2000-phi./varphi.*log(1-s(:,5))./g(3)-s(:,3))./beta(1);
        M=max(ones(n,1), M); %  A cannot be lower than 1
        Learnfactor=(1-beta(3)).*(1+g(6)*s(:,5)).^-1 + beta(3) .*M.^-beta(2); 
        %elseif strcmpi(learn,'endolearn'); Timefact=((beta(1)+2000-phi./varphi.*log(1-s(:,5))./g(3)-s(:,3))/beta(1)).^beta(2);
        elseif strcmpi(learn,'nolearn'); Learnfactor=1; 
        elseif strcmpi(learn,'nolearn2030'); Learnfactor=1/(1+g(6)*(1-exp(-g(3)*10))); %identical mac in 2030 if varphi0 of learning model is used
        else; disp('learn ill defined'); 
    end                        
    y=A0*s(:,4).*s(:,2).^alpha.*exp((phi.*s(:,1)-varphi./2.*s(:,1).^2).*Learnfactor-polyval(gammaT,s(:,3).*zeta));
    StrCost = theta(1).*          (-(x(:,1)<0).*x(:,1)).^theta(2)./s(:,2);
    StrCostid=-theta(1)*theta(2).*(-(x(:,1)<0).*x(:,1)).^(theta(2)-1)./s(:,2);
    StrCostidid=theta(1)*theta(2)*(theta(2)-1).*(-(x(:,1)<0).*x(:,1)).^(theta(2)-2)./s(:,2); %if theta(2)==2;(x(:,1)<0).*theta(1)*2;end
    c=y-x(:,1)-x(:,2)-StrCost;
    if any(c<0); disp 'negative consumption';end
    c(c<0)=0.001;

    cid=-1-StrCostid; %derivative of consumption with respect to id
    cidid=-StrCostidid;  
        out1=1/(1-eta)*c.^(1-eta);
        if nargout>1
        out2=[c.^(-eta).*cid            -c.^(-eta)]; 
        end
        if nargout>2
        out3=zeros(n,dx,dx);
        out3(:,1,1)=-eta.*c.^(-eta-1).*cid.^2+c.^(-eta).*cidid; 
        out3(:,1,2)= eta.*c.^(-eta-1).*cid;
        out3(:,2,1)=out3(:,1,2);
        out3(:,2,2)=-eta.*c.^(-eta-1);
        end
        if ~isreal(out1);disp('complex utility');disp(sum(imag(out1)));end
        if any(imag(out1));out1=real(out1);end
case 'g'
    e(:,2)=e(:,2).*(1-b(2,2).*((s(:,2)>=sbounds(2)).*(x(:,2)>3.999)+(s(:,2)<=sbounds(1)).*(x(:,2)<2.3)));%shock on dirty capital reduced by 50% if kapital is at upper node and investment is high and if kapital is at lower node and investment is low. Growth-adjusted decay is 63.8*0.065=4.14 at upper node and 36.1*0.065=2.34 at lower node. dependence on x may create corner solutions in maximization.
    e(:,3)=e(:,3).*(1-b(2,3).*(s(:,3)>=sbounds(3)));%At highest temp node, brownian motion on temperature is shrunk by 50% 
    e(:,4)=e(:,4).*(1-b(2,4).*(s(:,4)<=sbounds(4))); %At lowest tfp node brownian motion is reduced by 1.7%*0.4, less than last mean-reverting term 
    e(:,5)=e(:,5).*(1-b(2,5).*(s(:,4)<=sbounds(4))); %At lowest tfp node with jumpreduction of 71% At+1=0.687*(1-0.29*0.2)= 0.647
    kd=(s(:,1)./psi0./L0./(1+s(:,5)));
    out1=[(x(:,1)-chi(1).*x(:,1).^2./s(:,2)+(1-delta(1)-g(1)-g(2)+e(:,1)).*kd).*psi0.*L0.*(1+1-(1-s(:,5)).*exp(-g(3))),... %kd_(t+1)*psi0*L0*(1+tau_(t+1))
          x(:,1)+x(:,2)-chi(2)./s(:,2).*(x(:,1).^2+x(:,2).^2)+(1-delta(2)-g(1)-g(2)).*s(:,2)+e(:,1).*kd+e(:,2).*(s(:,2)-kd),... 
          s(:,1)+s(:,3).*(1+e(:,3)), ...  
          (1+g(5)-(1+xi2.*zeta.*s(:,3)).*e(:,5)+e(:,4)).*s(:,4)+g(7)*(1-s(:,4)), ...
          1-(1-s(:,5)).*exp(-g(3))];
    if nargout>1
    out2=zeros(n,ds,dx);
    out2(:,1,1)=(ones(n,1)-2*chi(1)./s(:,2).*x(:,1)).*psi0.*L0.*(1+1-(1-s(:,5)).*exp(-g(3)));
    out2(:,2,1)=ones(n,1)-2*chi(2)./s(:,2).*x(:,1);
    out2(:,2,2)=ones(n,1)-2*chi(2)./s(:,2).*x(:,2);
    end
    if nargout>2
    out3=zeros(n,ds,dx,dx);
    out3(:,1,1,1)=-2*chi(1)./s(:,2).*psi0.*L0.*(1+1-(1-s(:,5)).*exp(-g(3)));
    out3(:,2,1,1)=-2*chi(2)./s(:,2).*ones(n,1);
    out3(:,2,2,2)=-2*chi(2)./s(:,2).*ones(n,1);
    end
end 